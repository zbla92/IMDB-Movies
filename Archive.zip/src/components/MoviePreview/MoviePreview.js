import React from 'react';

class MoviePreview extends React.Component {
  render() {
    return (
      <div className="movie-preview">
        <div>dang</div>
      </div>
    );
  }
}

export default MoviePreview;

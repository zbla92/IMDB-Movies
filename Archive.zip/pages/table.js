import React, { Component, Fragment } from 'react';

import Layout from '../src/components/Layout';

class Table extends Component {
  render() {
    return (
      <div>
        <Layout>
          <h1>bang</h1>
        </Layout>
      </div>
    );
  }
}

export default Table;

import React from 'react';
import Layout from '../src/components/Layout';

const test = props => {
  return <Layout>Bang</Layout>;
};

export default test;
